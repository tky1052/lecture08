 function fizz(parameter){
   if(parameter % 3 == 0){
     return "fizz";
   }
   return parameter;
 }
