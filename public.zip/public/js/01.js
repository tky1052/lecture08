function id (r){
  return r ;
}
