function buzz(r){
  if(r % 5 == 0){
    return "buzz";
  }
  return r;
}
